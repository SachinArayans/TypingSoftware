<!DOCTYPE html>

<html lang="en">
    <head>
        <title>Contact | TheTypers.com</title>
        <!--meta tags-->
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
        <meta name="Keywords" content="Typing,test,Number,Custom keys,English,Review,Hindi typing,fast,WPM,tutorials,Data entery,training,learning,lessons,tips">
        <meta name="Description" content="Typing Tutorial well Devided in lessons. Take a test and Test your typing speed. ">
        <!--css include-->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet"  href="css/sty.css">
        <link rel="stylesheet" href="css/font-awesome.css">
        <link rel="icon" href="img\favicon.ico" type="image/x-icon">
        <script src="script/analytics.js"></script>
    </head>
    <body>
<!-- facebook implement-->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

        <!--topmenu-->
<div class="top-menu"id="main-menu">
            </div>
        <script src="script/main-menu.js"></script>
                    
        <!--sidemenu-->
        <div class="lside">
                    </div><div class="men">
  
        
            <!--mainbody-->
               <div class="main-manual" id="about" style="margin-left: 20px;">
               <h2>Contact Us</h2>
                   <p>Email:  <a href="mailto:contact@thetypers.com">contact@thetypers.com</a></p><br>
<p>Email:  <a href="mailto:ceo@thetypers.com">ceo@thetypers.com</a></p>

                <h2>Want to say thanks to <span style="color:#0C5DA3;">The<span style="color:#03AAAC;">Typers</span>.com</span> , Hit the like button.</h2>
                 
<center><table style="border:0px;width:100%;font-size:25px;"><th>Like</th><th>Timeline</th><tr><td>
<div class="fb-page" 
  data-tabs="timeline"
  data-href="https://www.facebook.com/thetypers/"
  data-width="500" 
  data-hide-cover="false"></div></td><td>
<div class="fb-page" 
  data-tabs="messages"
  data-href="https://www.facebook.com/thetypers/"
  data-width="500" 
  data-hide-cover="false"></div></td></tr></table></center>
        <!--<h2>Contact our employess</h2>-->
                  <h3>For any type of query, suggestion and information contact us at <a href="mailto:contact@thetypers.com">contact@thetypers.com</a></h3>



                   </p>
               </div>
                            
                          </div>
        </div><div class="rside">
                    <!--rightside--><br>
SHARE<br>
             <div style="font-size: 35px;">
<a href="http://www.facebook.com/sharer.php?u=http://www.thetypers.com/about.html"><i class="fa fa-facebook-square"></i></a>
<a href="https://twitter.com/home?status=Be a fast Typer with http://thetypers.com/about.html"><i class="fa fa-twitter-square"></i></a>
<a href="https://plus.google.com/share?url=http://www.thetypers.com/about.html">    <i class="fa fa-google-plus-square"></i></a>
        </div><br>
        
             
                <img src="img/credit.png" class="advt" alt="banner1">
         <br> <span><a href="about.html#1">&copy; 2017 thetypers.com All Rights Reserved</a></span><br><br>
        </div>
         <!--script include-->
        <script src="script/jquery.min.js"></script>
        <script src="script/keys.js"></script>
        <script src="script/ajmain.js"></script>
                   </body>
</html>
